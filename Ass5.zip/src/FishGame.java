import javalib.worldimages.*;
import java.util.Random;
import javalib.funworld.*;

interface IObject {
  double FRICTION_COEF = 0.95;
  double STEP = 1;

  // Returns a WorldImage of self
  WorldImage drawSelf();

  // Sets this object's x & y coordinates to the given arguments
  IObject place(int xPos, int yPos);

  // Return this object's x coordinate
  int getX();

  // Return this object's y coordinate
  int getY();
}

abstract class AFish implements IObject {
  double size;
  int fishType;
  boolean isAlive;
  boolean isFacingRight;
  int xPos;
  int yPos;

  /*- 
   * Fields:
   * size : double
   * fishType : int
   * isAlive : boolean
   * isFacingRight : boolean
   * xPos : int
   * yPos : int
   * 
   * Methods:
   * this.drawSelf() : WorldImage
   * this.getX() : int
   * this.getY() : int
   * this.move(String ke) : AFish
   */

  AFish(double size, int fishType, boolean isAlive, boolean isFacingRight, int xPos, int yPos) {
    this.size = size;
    this.fishType = fishType;
    this.isAlive = isAlive;
    this.isFacingRight = isFacingRight;
    this.xPos = xPos;
    this.yPos = yPos;
  }

  // Returns the image of this fish
  public WorldImage drawSelf() {
    String path = "PNG/Fish".concat(Integer.toString(fishType)).concat(".png");
    if (isFacingRight) {
      return new ScaleImage(new FromFileImage(path), size);
    }
    else {
      return new ScaleImageXY(new ScaleImage(new FromFileImage(path), size), -1, 1);
    }
  }

  public int getX() {
    return this.xPos;
  }

  public int getY() {
    return this.yPos;
  }

  // Moves the fish according to the given KeyEvent
  abstract AFish move(String ke);
}

class Player extends AFish {
  int score;
  double xVel;
  double yVel;

  /*-
   * Fields:
   * size : double
   * fishType : int
   * isAlive : boolean
   * isFacingRight : boolean
   * xPos : int
   * yPos : int
   * score: int
   * xVel: double
   * yVel: double
   * 
   * Method: 
   * this.move(String ke): Player
   * this.isOutOfBounds(int width, int height): String
   * this.place(int xPos, int yPos): Player
   * this.bounceTop(): Player
   * this.bounceBottom(): Player
   * this.isTouching(INPC first): boolean
   * this.xBordersTouching(INPC that): boolean
   * this.yBordersTouching(INPC that): boolean
   * this.canEat(INPC that): boolean
   * this.kill(): Player
   */

  Player(double size, int fishType, boolean isAlive, boolean isFacingRight, int xPos, int yPos,
      double xVel, double yVel, int score) {
    super(size, fishType, isAlive, isFacingRight, xPos, yPos);
    this.xVel = xVel;
    this.yVel = yVel;
    this.score = score;
    this.fishType = 0;
  }

  // Moves the player fish according to the keyevent
  Player move(String ke) {
    if (ke.equals("right")) {
      xVel += STEP / this.size;
      isFacingRight = true;
    }
    else if (ke.equals("left")) {
      xVel -= STEP / this.size;
      isFacingRight = false;
    }
    else if (ke.equals("up")) {
      yVel -= STEP / this.size;
    }
    else if (ke.equals("down")) {
      yVel += STEP / this.size;
    }
    xVel *= FRICTION_COEF;
    yVel *= FRICTION_COEF;
    return new Player(size, fishType, isAlive, isFacingRight, (int) (xPos + xVel + 0.5),
        (int) (yPos + yVel + 0.5), xVel, yVel, score);
  }

  // Returns where this Player is out of bounds ("left", "right",
  // "up" etc), else returns "in"
  // Assumes 128*128 dimensions
  public String isOutOfBounds(int width, int height) {
    if (this.xPos <= -this.size * 64 || this.yPos <= this.size * 64) {
      if (this.xPos < 0) {
        return "left";
      }
      return "up";
    }
    if (this.xPos >= width + this.size * 64 || this.yPos >= height - this.size * 64 - 216) {
      if (this.xPos > width) {
        return "right";
      }
      return "down";
    }
    else {
      return "in";
    }
  }

  // Returns a new Player at the specified position
  public Player place(int xPos, int yPos) {
    return new Player(this.size, this.fishType, this.isAlive, this.isFacingRight, xPos, yPos,
        this.xVel, this.yVel, this.score);
  }

  // Returns a new Player with -1 * this Player's velocities & a little lower
  public Player bounceTop() {
    return new Player(this.size, this.fishType, this.isAlive, this.isFacingRight, this.xPos,
        this.yPos + 3, this.xVel, -this.yVel + 2, this.score);
  }

  // Returns a new Player with -1 * this Player's velocities & a little higher
  public Player bounceBottom() {
    return new Player(this.size, this.fishType, this.isAlive, this.isFacingRight, this.xPos,
        this.yPos - 3, this.xVel, -this.yVel - 2, this.score);
  }

  // Return if this player is touching the given object
  boolean isTouching(INPC first) {
    return xBordersTouching(first) && yBordersTouching(first);
  }

  // Returns the x component of the length of the line connecting the two closest
  // points on the borders of the hitboxes of this and that (negative means
  // overlap)
  boolean xBordersTouching(INPC that) {
    int distBetweenCenters = Math.abs(this.getX() - that.getX()) + 30;
    return distBetweenCenters < (this.drawSelf().getWidth() / 2 + that.drawSelf().getWidth() / 2);
  }

  // Returns the y component of the length of the line connecting the two closest
  // points on the borders of the hitboxes of this and that (negative means
  // overlap)
  boolean yBordersTouching(INPC that) {
    int distBetweenCenters = Math.abs(this.getY() - that.getY()) + 30;
    return distBetweenCenters < (this.drawSelf().getHeight() / 2 + that.drawSelf().getHeight() / 2);
  }

  // Returns true if this Player can eat that NPC
  boolean canEat(INPC that) {
    return that.getSize() < this.size + 0.1;
  }

  // Kill the Player
  Player kill() {
    return new Player(0, 0, false, false, 0, 0, 0, 0, this.score);
  }
}

interface ILoNPC {

  // Returns a WorldScene with all the NPCs in the ILoNPC drawn on top of it
  WorldScene drawAllNPC(WorldScene w);

  // Moves all NPCs the appropriate amount
  ILoNPC moveAllNPC();

  // Returns all NPCs in the current list that the given player is currently
  // touching
  ILoNPC touching(Player player);

  // Resolves any collisions with the Player and this & returns the new player
  Player resolveCollision(Player player);

  // Removes any dead NPCs from this list
  ILoNPC cleanup();

  // If the current list is empty, make a new batch of NPCs
  ILoNPC generate(int numToGenerate, int width, int height, Random r);

  // If a NPC in this has completed its gauntlet across the screen, kill it
  ILoNPC killCrossed(int width, int height);

  // Returns the largest fish's size
  double largest(double max);

  // Returns this list with a snack added
  Snack makeSnack(int width, int height, Random r);

}

class MtLoNPC implements ILoNPC {

  // Returns a WorldScene with all the NPCs in the ILoNPC drawn on top of it
  public WorldScene drawAllNPC(WorldScene w) {
    return w;
  }

  // Moves all NPCs the appropriate amount
  public ILoNPC moveAllNPC() {
    return this;
  }

  // Returns all NPCs in the current list that the given player is currently
  // touching
  public ILoNPC touching(Player player) {
    return this;
  }

  // Resolves any collisions with the Player and this & return the resulting
  // Player
  public Player resolveCollision(Player player) {
    return player;
  }

  // Removes any dead NPCs from this list
  public ILoNPC cleanup() {
    return this;
  }

  // Generate a new batch of NPCs
  public ILoNPC generate(int numToGenerate, int width, int height, Random r) {
    if (numToGenerate == 0) {
      return new MtLoNPC();
    }
    boolean isFacingRight;
    int yPos = r.nextInt(height - 216);
    int xPos;
    if (r.nextBoolean()) {
      isFacingRight = true;
      xPos = r.nextInt(width) - width - 128;
    }
    else {
      isFacingRight = false;
      xPos = r.nextInt(width) + width + 128;
    }
    double size = (r.nextInt(200) + 50) / 100;
    if (new Player(size, r.nextInt(4) + 1, true, isFacingRight, xPos, yPos, 0, 0, 0)
        .isOutOfBounds(width, height).equals("in")) {
      return this.generate(numToGenerate, width, height, r);
    }
    if (numToGenerate != 1) {
      return new ConsLoNPC(new NPCFish(size, r.nextInt(4) + 1, true, isFacingRight, xPos, yPos),
          this.generate(numToGenerate - 1, width, height, r));
    } // else
    return new ConsLoNPC(this.makeSnack(width, height, r),
        new ConsLoNPC(new NPCFish(size, r.nextInt(4) + 1, true, isFacingRight, xPos, yPos),
            this.generate(numToGenerate - 1, width, height, r)));
  }

  // If a NPC in this has completed its gauntlet across the screen, kill it
  public ILoNPC killCrossed(int width, int height) {
    return this;
  }

  // Returns the largest fish's size
  public double largest(double max) {
    return max;
  }

  // Returns this list with a snack added
  public Snack makeSnack(int width, int height, Random r) {
    int xPos = r.nextInt(width - 128) + 64;
    int yPos = r.nextInt(height - 310) + 64;
    return new Snack(xPos, yPos, true);
  }

}

class ConsLoNPC implements ILoNPC {
  INPC first;
  ILoNPC rest;

  /*- 
   * Fields:
   * first : INPC
   * rest : ILoNPC
   * 
   * Methods:
   * this.drawAllNPC(WorldScene w) : WorldScene
   * this.moveAllNPC() : ILoNPC
   * this.touching(Player player) : ILoNPC
   * this.resolveCollision(Player player) : Player
   * this.cleanup() : ILoNPC
   * this.generate(int numToGenerate,int width, int height, Random r) : ILoNPC
   * this.killCrossed(int width, int height) : ILoNPC
   * this.largest(double max) : double
   * this.addSnack(int width, int height, Random r) : Snack
   * 
   * Methods of Fields:
   * rest.drawAllNPC(WorldScene w) : WorldScene
   * rest.moveAllNPC() : ILoNPC
   * rest.touching(Player player) : ILoNPC
   * rest.resolveCollision(Player player) : Player
   * rest.cleanup() : ILoNPC
   * rest.generate(int numToGenerate,int width, int height, Random r) : ILoNPC
   * rest.killCrossed(int width, int height) : ILoNPC
   * rest.largest(double max) : double
   * rest.addSnack(int width, int height, Random r) : Snack
   * 
   * first.drawSelf() : WorldImage
   * first.move(String string) : INPC
   * first.getX() : int
   * first.getY() : int
   * first.getSize() : double
   * first.resolveCollision(Player player) : double
   * first.isAlive() : boolean
   * first.getFacingRight() : boolean
   */

  ConsLoNPC(INPC first, ILoNPC rest) {
    this.first = first;
    this.rest = rest;
  }

  // Returns a WorldScene with all the NPCs in the ILoNPC drawn on top of it
  public WorldScene drawAllNPC(WorldScene w) {
    return rest
        .drawAllNPC(w.placeImageXY(this.first.drawSelf(), this.first.getX(), this.first.getY()));
  }

  // Moves all NPCs the appropriate amount
  public ILoNPC moveAllNPC() {
    return new ConsLoNPC(first.move(""), rest.moveAllNPC());
  }

  // Returns all NPCs in the current list that the given player is currently
  // touching
  public ILoNPC touching(Player player) {
    if (player.isTouching(first)) {
      return new ConsLoNPC(first, rest.touching(player));
    }
    return rest.touching(player);
  }

  // Resolves any collisions with the Player and this and return the resulting
  // Player
  public Player resolveCollision(Player player) {
    double sizeChange = this.first.resolveCollision(player);
    if (sizeChange < 0) {
      return player.kill();
    }
    else {
      return new Player(player.size + sizeChange, player.fishType, player.isAlive,
          player.isFacingRight, player.xPos, player.yPos, player.xVel, player.yVel,
          player.score + (int) ((sizeChange * 100) * (sizeChange * 100)));
    }

  }

  // Removes any dead NPCs from this list
  public ILoNPC cleanup() {
    if (first.isAlive()) {
      return new ConsLoNPC(first, rest.cleanup());
    } // else
    return rest.cleanup();
  }

  // If the list is empty, generate a new batch of NPCs
  public ILoNPC generate(int numToGenerate, int width, int height, Random r) {
    return this;
  }

  // If a NPC in this has completed its gauntlet across the screen, kill it
  public ILoNPC killCrossed(int width, int height) {
    if ((first.getFacingRight() && first.getX() > width + 128)
        || (!(first.getFacingRight()) && first.getX() < -128)) {
      return rest.killCrossed(width, height);
    } // else
    return new ConsLoNPC(first, rest.killCrossed(width, height));
  }

  // Returns the largest fish's size
  public double largest(double max) {
    if (first.getSize() > max) {
      return this.rest.largest(first.getSize());
    }
    return this.rest.largest(max);
  }

  // Returns this list with a snack added
  public Snack makeSnack(int width, int height, Random r) {
    int xPos = r.nextInt(width - 128) + 64;
    int yPos = r.nextInt(height - 310) + 64;
    return new Snack(xPos, yPos, true);
  }
}

interface INPC extends IObject {

  // Returns a WorldImage of this NPC
  WorldImage drawSelf();

  // Moves this NPC
  INPC move(String string);

  // Return this object's x coordinate
  int getX();

  // Return this object's y coordinate
  int getY();

  // Return the size of this object (0 for a snack)
  double getSize();

  // Returns the new size of the player after the collision (-1 for death)
  double resolveCollision(Player player);

  // Return if the given NPC is alive
  boolean isAlive();

  // Returns if the given NPC is facing right (true for Snacks)
  boolean getFacingRight();
}

class Snack implements INPC {

  /*-
   * Fields: 
   * xPos: int
   * yPos; int
   * isAlive: boolean
   * 
   * 
   * Methods:
   * this.drawSelf() : WorldImage
   * this.move(String string) : INPC
   * this.getX() : int
   * this.getY() : int
   * this.getSize() : double
   * this.resolveCollision(Player player) : double
   * this.isAlive() : boolean
   * this.getFacingRight() : boolean
   * this.place(int xPos, int yPos): Snack
   */

  // Size is defined as 0 so all snacks can be eaten
  double size = 0;
  int xPos;
  int yPos;
  boolean isAlive;

  Snack(int xPos, int yPos, boolean isAlive) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.isAlive = isAlive;
  }

  // Returns the image of this fish
  public WorldImage drawSelf() {
    String path = "PNG/SizeSnack.png";
    return new ScaleImage(new FromFileImage(path), 0.5);
  }

  // Return this object's X coordinate
  public int getX() {
    return this.xPos;
  }

  // Return this object's Y coordinate
  public int getY() {
    return this.yPos;
  }

  // Allows for this NPC to be moved with all others - snacks stay stationary
  public INPC move(String string) {
    return this;
  }

  // Return the size of this object (0 for a snack)
  public double getSize() {
    return this.size;
  }

  // Gives the player size increase
  public double resolveCollision(Player player) {
    this.isAlive = false;
    return 0.1 * player.size;
  }

  // Return if the given NPC is alive
  public boolean isAlive() {
    return this.isAlive;
  }

  // Returns if the given NPC is facing right (true for Snacks)
  public boolean getFacingRight() {
    return true;
  }

  // Places this Snack at the given coordinates
  public Snack place(int xPos, int yPos) {
    return new Snack(xPos, yPos, this.isAlive);
  }
}

class NPCFish extends AFish implements INPC {
  /*-
   * Fields:
   * size: double
   * fishType: int
   * isAlive: int
   * isFacingRight: boolean
   * xPos: int
   * yPos: int
   * 
   * Methods:
   * this.move(String ke): NPCFish
   * this.place(int xPos, int yPos): NPCFish
   * this.getSize(): double
   * this.resolveCollosion(Player player): double
   * this.isAlive(): boolean
   * this.getFacingRight(): boolean
   */
  NPCFish(double size, int fishType, boolean isAlive, boolean isFacingRight, int xPos, int yPos) {
    super(size, fishType, isAlive, isFacingRight, xPos, yPos);
  }

  // Moves fish
  public NPCFish move(String ke) {
    if (isFacingRight) {
      return new NPCFish(this.size, fishType, isAlive, isFacingRight, (int) (xPos + STEP + 0.5),
          yPos);
    }
    return new NPCFish(this.size, fishType, isAlive, isFacingRight, (int) (xPos - STEP), yPos);
  }

  // Places this NPCFish at the given coordinates
  public NPCFish place(int xPos, int yPos) {
    return new NPCFish(this.size, this.fishType, this.isAlive, this.isFacingRight, xPos, yPos);
  }

  // Return the size of this object (0 for a snack)
  public double getSize() {
    return this.size;
  }

  // Resolves any collisions with the Player and this & return the size change
  public double resolveCollision(Player player) {
    if (player.canEat(this) && player.isTouching(this)) {
      this.isAlive = false;
      return this.getSize() / 15;
    }
    return -1;
  }

  // Return if the given NPC is alive
  public boolean isAlive() {
    return this.isAlive;
  }

  // Returns if the given NPC is facing right (true for Snacks)
  public boolean getFacingRight() {
    return this.isFacingRight;
  }
}
