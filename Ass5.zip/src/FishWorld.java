import java.util.Random;

import javalib.funworld.*;
import javalib.worldimages.*;

class FishWorld extends World {
  int height = 1024;
  int width = 1024;
  Player player;
  ILoNPC others;
  Random r;

  /*-
   * Fields:
   * height : int
   * width : int
   * player : Player
   * others : ILoNPC
   * r : Random
   * 
   * Methods: 
   * FishWorld.makeScene() : WorldScene
   * FishWorld.onKeyEvent(String ke) : FishWorld
   * FishWorld.onTick() : FishWorld
   * FishWorld.resolveoutOfBounds() : FishWorld
   * FishWorld.resolveCollisions() : FishWorld
   * FishWorld.cleanup() : FishWorld
   * FishWorld.drawScore(int score) : WorldImage
   * FishWorld.drawDigit(int digit) : WorldImage
   * FishWorld.worldEnds() : WorldEnd
   * FishWorld.makeEndScene() : WorldScene
   * FishWorld.makeEndScene(int score) : WorldScene
   * 
   * Methods of Fields:
   * player.move(String ke): Player
   * player.isOutOfBounds(int width, int height): String
   * player.place(int xPos, int yPos): Player
   * player.bounceTop(): Player
   * player.bounceBottom(): Player
   * player.isTouching(INPC first): boolean
   * player.xBordersTouching(INPC that): boolean
   * player.yBordersTouching(INPC that): boolean
   * player.canEat(INPC that): boolean
   * player.kill(): Player
   * others.drawAllNPC(WorldScene w) : WorldScene
   * others.moveAllNPC() : ILoNPC
   * others.touching(Player player) : ILoNPC
   * others.resolveCollision(Player player) : Player
   * others.cleanup() : ILoNPC
   * others.generate(int numToGenerate,int width, int height, Random r) : ILoNPC
   * others.killCrossed(int width, int height) : ILoNPC
   * others.largest(double max) : double
   * others.addSnack(int width, int height, Random r) : Snack
   */
  public FishWorld(Player player, ILoNPC others, Random r) {
    super();
    this.player = player;
    this.others = others;
    this.r = r;
  }

  // Produce the image of this world by adding the Player & any other NPCs onto
  // the background
  // This is called every tick
  public WorldScene makeScene() {

    // Make an empty scene and place the background on it
    WorldScene worldScene = new WorldScene(this.height, this.width);
    WorldScene background = worldScene.placeImageXY(new FromFileImage("PNG/BG.png"), 512, 512);

    // Place the player sprite on the background & draw all other NPCs
    WorldImage playerImage = player.drawSelf();
    WorldImage scoreImage = drawScore(player.score);
    return this.others.drawAllNPC(background.placeImageXY(playerImage, player.xPos, player.yPos))
        .placeImageXY(scoreImage, (int) scoreImage.getWidth() / 2,
            (int) scoreImage.getHeight() / 2);
  }

  // Overrides the onKeyEvent method to react to keypresses
  public FishWorld onKeyEvent(String ke) {
    return new FishWorld(player.move(ke), others, r);
  }

  // Overrides the onTick() method to do everything necessary for the world
  public FishWorld onTick() {
    return new FishWorld(player.move(""),
        others.generate(20, width, height, r).killCrossed(width, height), r).resolveoutOfBounds()
            .resolveCollisions().cleanup();
  }

  // Resolves any out of bounds issues in this FishWorld
  FishWorld resolveoutOfBounds() {
    if (player.isOutOfBounds(width, height).equals("right")) {
      return new FishWorld(player.place((int) -(64 * player.size), player.yPos),
          others.moveAllNPC(), r);
    }
    else if (player.isOutOfBounds(width, height).equals("left")) {
      return new FishWorld(player.place((int) (width + (64 * player.size)), player.yPos),
          others.moveAllNPC(), r);
    }
    if (player.isOutOfBounds(width, height).equals("up")) {
      return new FishWorld(player.bounceTop(), others.moveAllNPC(), r);
    }
    if (player.isOutOfBounds(width, height).equals("down")) {
      return new FishWorld(player.bounceBottom(), others.moveAllNPC(), r);
    }
    return new FishWorld(player, others.moveAllNPC(), r);
  }

  // Resolves any collisions in this FishWorld
  FishWorld resolveCollisions() {
    return new FishWorld(others.touching(player).resolveCollision(player), others, r);
  }

  // Removes any dead IObjects from others
  FishWorld cleanup() {
    if (player.isAlive) {
      return new FishWorld(player, others.cleanup(), r);
    }
    return new FishWorld(player.kill(), others.cleanup(), r);
  }

  // Returns the score as a WorldImage
  WorldImage drawScore(int score) {
    if (score == 0) {
      return new EmptyImage();
    }
    return new BesideImage(drawScore(score / 10), drawDigit(score % 10));
  }

  // Returns the given digit as a WorldImage
  WorldImage drawDigit(int digit) {
    return new FromFileImage("PNG/Number-".concat(Integer.toString(digit)).concat(".png"))
        .movePinhole(64, 0);
  }

  // Displays the correct WorldScene when the player is dead or has won
  public WorldEnd worldEnds() {
    if (!player.isAlive) {
      return new WorldEnd(true, this.makeEndScene());
    }
    else if (others.largest(0) <= player.size && others.largest(0) > 0.1) {
      return new WorldEnd(true, makeEndScene(player.score));
    }
    else {
      return new WorldEnd(false, this.makeScene());
    }
  }

  // Returns the Game Over scene
  WorldScene makeEndScene() {
    WorldImage gameOver = new FromFileImage("PNG/GameOver.png");
    return new FishWorld(new Player(0, 0, false, false, -100000, -100000, 0, 0, player.score),
        new MtLoNPC(), r).makeScene().placeImageXY(gameOver, width / 2, height / 2 - 100);
  }

  // Returns the Winner scene
  WorldScene makeEndScene(int score) {
    WorldImage gameOver = new FromFileImage("PNG/Winner.png");
    return new FishWorld(new Player(0, 0, false, false, -100000, -100000, 0, 0, score),
        new MtLoNPC(), r).makeScene().placeImageXY(gameOver, width / 2, height / 2 - 100);
  }

}