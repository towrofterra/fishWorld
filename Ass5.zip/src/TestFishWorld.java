import java.util.Random;

import javalib.funworld.*;
import javalib.worldcanvas.*;
import javalib.worldimages.*;
import tester.*;

class TestFishWorld {
  int height = 1024;
  int width = 1024;
  Player testPlayer = new Player(1, 1, true, true, width / 2, height / 3, 0, 15, 0);
  Player testPlayerStatic = new Player(1, 1, true, true, width / 2, height / 3, 0, 0, 0);
  Random r = new Random();
  NPCFish npc1 = new NPCFish(1.5, 2, true, false, 1024, 250);
  NPCFish npc2 = new NPCFish(1, 4, true, true, 0, 650);
  NPCFish npc3 = new NPCFish(0.5, 3, true, true, 0, 300);
  NPCFish npcTouchingPlayer = new NPCFish(0.5, 1, true, true, width / 2, height / 3);
  NPCFish npcTouchingPlayer2 = new NPCFish(1, 5, true, true, width / 2, height / 3);
  NPCFish deadNPC1 = new NPCFish(1, 2, false, true, 200, 200);
  NPCFish deadNPC2 = new NPCFish(0.5, 3, false, false, 400, 200);
  NPCFish deadNPC3 = new NPCFish(1.5, 4, false, true, 200, 400);
  NPCFish npcCrossed = new NPCFish(2, 3, true, false, -600, 500);

  INPC sizeSnack1 = new Snack(100, 700, true);

  Player playerOOBRight = new Player(1, 4, true, false, width * 3, 600, width * 2, 600, 0);
  Player playerOOBUp = new Player(1, 4, true, false, 600, -height, 600, -600, 0);
  Player playerOOBDown = new Player(1, 4, true, false, 600, height * 3, 600, height * 2, 0);
  Player playerOOBLeft = new Player(1, 4, true, false, width * -3, 600, -600, 600, 0);
  Player playerOOBUpBorder = new Player(1, 1, true, true, 600, -65, 600, 0, 0);
  ILoNPC loNPC1 = new ConsLoNPC(npc1, new MtLoNPC());
  ILoNPC loNPC2 = new ConsLoNPC(npc2, loNPC1);
  ILoNPC loNPC3 = new ConsLoNPC(npc3, loNPC2);
  ILoNPC loNPC4 = new ConsLoNPC(sizeSnack1, loNPC3);
  ILoNPC loNPCTouching = new ConsLoNPC(npcTouchingPlayer,
      new ConsLoNPC(npcTouchingPlayer2, new MtLoNPC()));
  ILoNPC loNPCTouching2 = new ConsLoNPC(npcTouchingPlayer, new MtLoNPC());
  ILoNPC loDead = new ConsLoNPC(deadNPC1,
      new ConsLoNPC(deadNPC2, new ConsLoNPC(deadNPC3, new MtLoNPC())));

  FishWorld fw = new FishWorld(testPlayer, new MtLoNPC(), r);

  boolean testDrawWorld(Tester t) {
    WorldCanvas c = new WorldCanvas(width, height);
    WorldScene s = fw.makeScene();
    return c.drawScene(s);
  }

  boolean testOutOfBounds(Tester t) {
    return t.checkExpect(testPlayer.isOutOfBounds(width, height), "in")
        && t.checkExpect(playerOOBRight.isOutOfBounds(width, height), "right")
        && t.checkExpect(playerOOBUp.isOutOfBounds(width, height), "up")
        && t.checkExpect(playerOOBDown.isOutOfBounds(width, height), "down")
        && t.checkExpect(playerOOBLeft.isOutOfBounds(width, height), "left")
        && t.checkExpect(playerOOBUpBorder.isOutOfBounds(width, height), "up");
  }

  boolean testDrawSelf(Tester t) {
    return t.checkExpect(testPlayer.drawSelf(),
        new ScaleImage(new FromFileImage("PNG/Fish0.png"), testPlayer.size))
        && t.checkExpect(npc1.drawSelf(),
            new ScaleImageXY(new ScaleImage(new FromFileImage("PNG/Fish2.png"), npc1.size), -1, 1));
  }

  boolean testTouching(Tester t) {
    return t.checkExpect(loNPC3.touching(testPlayer), new MtLoNPC())
        && t.checkExpect(loNPCTouching.touching(testPlayer),
            new ConsLoNPC(npcTouchingPlayer, new ConsLoNPC(npcTouchingPlayer2, new MtLoNPC())))
        && t.checkExpect(loNPCTouching2.touching(testPlayer),
            new ConsLoNPC(npcTouchingPlayer, new MtLoNPC()));
  }

  boolean testMoveAllNPC(Tester t) {
    return t.checkExpect(loNPC1.moveAllNPC(), new ConsLoNPC(npc1.move(""), new MtLoNPC()))
        && t.checkExpect(loNPC2.moveAllNPC(),
            new ConsLoNPC(npc2.move(""), new ConsLoNPC(npc1.move(""), new MtLoNPC())));
  }

  boolean testILoNPCResolveCollision(Tester t) {
    return t.checkExpect(new MtLoNPC().resolveCollision(testPlayer), testPlayer)
        && t.checkExpect(loNPCTouching.resolveCollision(testPlayer),
            new Player(1 + (1.0 / 30), testPlayer.fishType, testPlayer.isAlive,
                testPlayer.isFacingRight, testPlayer.xPos, testPlayer.yPos, testPlayer.xVel,
                testPlayer.yVel, 11));
  }

  boolean testGenerate(Tester t) {
    // int yPos3 = rSeed2.nextInt(height - 216);
    // boolean isFR1 = rSeed2.nextBoolean();
    // int xPos3 = r.nextInt(width) + width + 128;
    // r.nextInt(4); // To mimic the inside func
    // double size1 = (rSeed2.nextInt(200) + 50) / 100;
    // int fishType3 = rSeed2.nextInt(4) + 1;
    // int yPos2 = rSeed2.nextInt(height - 216);
    // boolean isFR2 = rSeed2.nextBoolean();
    // int xPos2 = rSeed2.nextInt(width) - width - 128;
    // double size2 = (rSeed2.nextInt(200) + 50) / 100;
    // int fishType2 = rSeed2.nextInt(4) + 1;
    // int yPos1 = rSeed2.nextInt(height - 216);
    // int xPos1 = rSeed2.nextInt(width) - width - 128;
    return t.checkExpect(loNPC1.generate(10, width, height, r), loNPC1)
        && t.checkExpect(loNPC2.generate(5, width, height, r), loNPC2)
        && t.checkExpect(new MtLoNPC().generate(2, width, height, new Random(1000)),
            new ConsLoNPC(new NPCFish(1.0, 1, true, false, 1740, 791),
                new ConsLoNPC(new Snack(679, 452, true),
                    new ConsLoNPC(new NPCFish(1, 2, true, true, -654, 185), new MtLoNPC()))));
  }

  boolean testCleanup(Tester t) {
    return t.checkExpect(loNPC3.cleanup(), loNPC3)
        && t.checkExpect(new MtLoNPC().cleanup(), new MtLoNPC())
        && t.checkExpect(loDead.cleanup(), new MtLoNPC());
  }

  boolean testKillCrossed(Tester t) {
    return t.checkExpect(loNPC4.killCrossed(width, height), loNPC4) && t.checkExpect(
        new ConsLoNPC(npcCrossed, new MtLoNPC()).killCrossed(width, height), new MtLoNPC());
  }

  boolean testLargest(Tester t) {
    return t.checkExpect(new MtLoNPC().largest(0), 0.0)
        && t.checkExpect(new MtLoNPC().largest(2), 2.0) && t.checkExpect(loNPC4.largest(0), 1.5);
  }

  boolean testMakeSnack(Tester t) {
    Random rSeed = new Random(1000);
    Random rSeed2 = new Random(1000);
    return t.checkExpect(loNPC3.makeSnack(width, height, rSeed2),
        new Snack(rSeed.nextInt(width - 128) + 64, rSeed.nextInt(height - 310) + 64, true))
        && t.checkExpect(new MtLoNPC().makeSnack(width, height, rSeed2),
            new Snack(rSeed.nextInt(width - 128) + 64, rSeed.nextInt(height - 310) + 64, true));
  }

  boolean testPlayerMove(Tester t) {
    return t.checkExpect(testPlayerStatic.move("left"), new Player(testPlayerStatic.size,
        testPlayerStatic.fishType, testPlayerStatic.isAlive, testPlayerStatic.isFacingRight,
        (int) (testPlayerStatic.xPos + 0.5 - (1 / testPlayerStatic.size)), testPlayerStatic.yPos,
        testPlayerStatic.xVel, testPlayerStatic.yVel, testPlayerStatic.score))
        && t.checkExpect(testPlayerStatic.move("right"),
            new Player(testPlayerStatic.size, testPlayerStatic.fishType, testPlayerStatic.isAlive,
                testPlayerStatic.isFacingRight,
                (int) (testPlayerStatic.xPos - 0.5 + (1 / testPlayerStatic.size)),
                testPlayerStatic.yPos, testPlayerStatic.xVel, testPlayerStatic.yVel,
                testPlayerStatic.score))
        && t.checkExpect(testPlayerStatic.move("up"),
            new Player(testPlayerStatic.size, testPlayerStatic.fishType, testPlayerStatic.isAlive,
                testPlayerStatic.isFacingRight, testPlayerStatic.xPos,
                (int) (testPlayerStatic.yPos + 0.5 - (1 / testPlayerStatic.size)),
                testPlayerStatic.xVel, testPlayerStatic.yVel, testPlayerStatic.score))
        && t.checkExpect(testPlayerStatic.move("down"),
            new Player(testPlayerStatic.size, testPlayerStatic.fishType, testPlayerStatic.isAlive,
                testPlayerStatic.isFacingRight, testPlayerStatic.xPos,
                (int) (testPlayerStatic.yPos - 0.5 + (1 / testPlayerStatic.size)),
                testPlayerStatic.xVel, testPlayerStatic.yVel, testPlayerStatic.score));
  }

  boolean testPlayerCanEat(Tester t) {
    return t.checkExpect(testPlayer.canEat(npc1), false)
        && t.checkExpect(testPlayer.canEat(npc2), true)
        && t.checkExpect(testPlayer.canEat(sizeSnack1), true);
  }

  boolean testPlayerKill(Tester t) {
    return t.checkExpect(testPlayer.kill(),
        new Player(0, 0, false, false, 0, 0, 0, 0, testPlayer.score));
  }

  boolean testPlayerIsTouching(Tester t) {
    return t.checkExpect(testPlayer.isTouching(npc1), false)
        && t.checkExpect(testPlayer.isTouching(npcTouchingPlayer), true);
  }

  boolean testPlayerPlace(Tester t) {
    return t.checkExpect(testPlayer.place(0, 0),
        new Player(testPlayer.size, testPlayer.fishType, testPlayer.isAlive,
            testPlayer.isFacingRight, 0, 0, testPlayer.xVel, testPlayer.yVel, testPlayer.score))
        && t.checkExpect(testPlayer.place(54, 20),
            new Player(testPlayer.size, testPlayer.fishType, testPlayer.isAlive,
                testPlayer.isFacingRight, 54, 20, testPlayer.xVel, testPlayer.yVel,
                testPlayer.score));
  }

  boolean testPlayerBounceTop(Tester t) {
    return t.checkExpect(testPlayer.bounceTop(),
        new Player(testPlayer.size, testPlayer.fishType, testPlayer.isAlive,
            testPlayer.isFacingRight, testPlayer.xPos, testPlayer.yPos + 3, testPlayer.xVel,
            -testPlayer.yVel + 2, testPlayer.score));
  }

  boolean testPlayerBounceBottom(Tester t) {
    return t.checkExpect(testPlayer.bounceBottom(),
        new Player(testPlayer.size, testPlayer.fishType, testPlayer.isAlive,
            testPlayer.isFacingRight, testPlayer.xPos, testPlayer.yPos - 3, testPlayer.xVel,
            -testPlayer.yVel - 2, testPlayer.score));
  }

   boolean testBigBang(Tester t) {
   return fw.bigBang(width, height, 0.01);
   }
}